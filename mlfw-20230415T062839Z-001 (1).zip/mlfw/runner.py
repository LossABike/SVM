from ranker import Ranker
r = Ranker('/content/drive/MyDrive/Code/mlfw/train','/content/drive/MyDrive/Code/mlfw/test', 2)